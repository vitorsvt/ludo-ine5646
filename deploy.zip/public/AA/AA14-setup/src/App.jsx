import React from 'react';
class HelloWorld extends React.Component {
    render() {
        return <h1>Hello World React Com JSX!</h1>;
    }
}
export default HelloWorld;
